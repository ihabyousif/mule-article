package com.confluex.components;

import org.mule.api.MuleEventContext;
import org.mule.api.lifecycle.Callable;

public class PaymentManagerComponent implements Callable{

	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		System.out.println("#####>>>>>> "+eventContext.getMessage().getPayload());
		return eventContext.getMessage().getPayload();
	}

}
